import os

# 获取当前工作目录
folder_path = os.getcwd()

# 用于存储已删除的文件
deleted_files = []

# 遍历当前文件夹中的所有文件
for filename in os.listdir(folder_path):
    if filename.endswith(".ann"):
        ann_file_path = os.path.join(folder_path, filename)
        txt_file_path = os.path.splitext(ann_file_path)[0] + '.txt'

        # 检查是否对应的 .ann 文件为空
        if os.path.getsize(ann_file_path) == 0:
            # 删除 .ann 文件
            os.remove(ann_file_path)
            deleted_files.append(filename)
            
            # 删除同名的 .txt 文件
            if os.path.exists(txt_file_path):
                os.remove(txt_file_path)
                deleted_files.append(os.path.basename(txt_file_path))

# 输出已删除的文件数目
num_deleted_files = len(deleted_files)
if num_deleted_files > 0:
    print(f"Deleted {num_deleted_files} files.")
else:
    print("No files were deleted.")
