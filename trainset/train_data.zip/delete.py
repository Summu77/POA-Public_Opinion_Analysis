import os

# 获取当前工作目录
current_directory = os.getcwd()

# 获取当前文件夹下所有文件和文件夹的列表
file_list = os.listdir(current_directory)

# 遍历文件列表，删除所有以"raw"为后缀的文件
for file_name in file_list:
    if file_name.endswith(".raw"):
        file_path = os.path.join(current_directory, file_name)
        os.remove(file_path)
        print(f"文件 {file_name} 已删除")

print("删除操作完成")
