import os

def merge_raw_files(output_filename='mytrain.raw'):
    # 获取当前文件夹下所有的raw文件名
    raw_files = [file for file in os.listdir() if file.endswith('.raw')]

    # 检查是否存在raw文件
    if not raw_files:
        print("当前文件夹下不存在.raw文件。")
        return

    # 打开合并后的文件
    with open(output_filename, 'wb') as merged_file:
        # 对每个raw文件进行合并
        for raw_file in raw_files:
            with open(raw_file, 'rb') as current_file:
                # 读取当前raw文件内容并写入合并后的文件
                merged_file.write(current_file.read())
                
    print(f"已成功将所有.raw文件合并为{output_filename}。")

# 调用函数合并所有raw文件
merge_raw_files()
