def generate_data_from_files(text_file, ann_file, output_file):
    # 读取文本文件
    with open(text_file, 'r', encoding='utf-8') as file:
        original_text = file.read().strip()

    
    if any(char.isalpha() and char.isascii() for char in original_text):
        print(original_text)
        print("文件内容包含英文字母，程序退出。")
        return

    
    # 读取注释文件
    with open(ann_file, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    # 生成数据
    generated_data = []
    for line in lines:
        if line.startswith('T'):
            parts = line.split('\t')
            entity_info = parts[1].split()

            entity_type = entity_info[0]
            start, end = int(entity_info[1]), int(entity_info[2])
            aspect = original_text[start:end]

            if entity_type not in ["Positive", "Neutral", "Negative"]:
                continue

            # 将"Positive", "Neutral", "Negative"映射为数字1, 0, -1
            entity_type_mapping = {"Positive": 1, "Neutral": 0, "Negative": -1}
            mapped_entity_type = entity_type_mapping[entity_type]

            # 替换偏移位置处的词为$T$
            modified_text = original_text[:start] + "$T$" + original_text[end:]

            # 生成三行数据
            generated_data.append(modified_text)
            generated_data.append(aspect)
            generated_data.append(mapped_entity_type)

    # 保存为 raw 格式文件
    with open(output_file, 'w', encoding='utf-8') as output:
        for data in generated_data:
            output.write(str(data) + '\n')



import os
import os

def process_all_txt_files_in_folder():
    # 获取当前文件夹下所有的txt文件名
    txt_files = [file for file in os.listdir() if file.endswith('.txt')]

    # 对每个txt文件进行处理
    for txt_file in txt_files:
        # 构造对应的ann文件名和output文件名
        ann_file = txt_file.replace('.txt', '.ann')
        output_file = txt_file.replace('.txt', '_output.raw')

        # 调用generate_data_from_files函数
        generate_data_from_files(txt_file, ann_file, output_file)


process_all_txt_files_in_folder()
